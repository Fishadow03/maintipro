MAINTIPRO — VERSION PWA MODIFIABLE
====================================

CONTENU
- index.html : interface + logique JavaScript (modifiable)
- manifest.webmanifest : nom et paramètres d'installation
- sw.js : cache hors ligne de l'interface
- icon.svg : icône

CE QUI FONCTIONNE DANS CETTE VERSION
- Écran d'accueil et compteurs
- Création de révisions et dépannages avec menus en cascade
- Machines de démonstration + ajout de machines
- Historique et recherche
- Échéances saisies manuellement
- Export/import JSON de sauvegarde locale

LIMITES ACTUELLES
- Données stockées uniquement dans le navigateur de l'appareil.
- Pas de synchronisation PC/iPhone, de comptes utilisateurs, ni de rendez-vous Outlook.
- Pour installer une PWA sur iPhone, le site doit être hébergé en HTTPS.
- Cette version n'est pas une application native App Store/IPA.

TEST / INSTALLATION SUR IPHONE
1. Héberger les fichiers du dossier sur un hébergeur HTTPS (par exemple GitHub Pages).
2. Ouvrir l'adresse HTTPS dans Safari.
3. Appuyer sur Partager > Sur l'écran d'accueil > Ajouter.
4. L'icône MaintiPro apparaît sur l'écran d'accueil.

MODIFIER LE CODE
- Ouvrir index.html dans un éditeur de texte pour modifier l'interface et le JavaScript.
- Le code de l'application est volontairement contenu dans index.html pour être facile à modifier.
- Après toute modification, re-déployer les fichiers sur l'hébergement.
- Si tu veux ajouter synchronisation, rappels et Outlook, il faudra ensuite connecter une base de données et un service de notifications.

IMPORTANT
Ne mets pas encore de données confidentielles ou personnelles de clients : il s'agit d'un prototype local de démonstration.
